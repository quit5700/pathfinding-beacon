package cn.quit5700.pathfindingbeacon.event;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.network.RouteNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;

import java.util.ArrayList;
import java.util.List;

public final class PlayerEvents {
    private static int ticks;

    private PlayerEvents() {
    }

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            handler.player.sendSystemMessage(Component.literal("寻路器取消指令pfcancel <1-30>"));
            RouteNetworking.syncPlayer(handler.player);
        });
        ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register((player, origin, destination) ->
                RouteNetworking.syncPlayer(player));
        ServerTickEvents.END_SERVER_TICK.register(PlayerEvents::unlockRecipesForPickaxeOwners);
    }

    private static void unlockRecipesForPickaxeOwners(MinecraftServer server) {
        if (++ticks % 20 != 0) {
            return;
        }
        List<ResourceKey<Recipe<?>>> ids = new ArrayList<>();
        ids.add(recipeKey("route_block_1"));
        for (int i = 2; i <= 30; i++) {
            ids.add(recipeKey("route_block_" + i));
        }
        ids.add(recipeKey("pathfinding_block_canceller"));
        ids.add(recipeKey("id_sequence_reorderer"));

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            boolean hasPickaxe = player.getInventory().getNonEquipmentItems().stream().anyMatch(PlayerEvents::isPickaxe);
            if (hasPickaxe) {
                player.awardRecipesByKey(ids);
            }
        }
    }

    private static boolean isPickaxe(ItemStack stack) {
        return stack.is(holder -> holder.is(ItemTags.PICKAXES));
    }

    private static ResourceKey<Recipe<?>> recipeKey(String path) {
        return ResourceKey.create(Registries.RECIPE, PathfindingBeaconMod.id(path));
    }
}
