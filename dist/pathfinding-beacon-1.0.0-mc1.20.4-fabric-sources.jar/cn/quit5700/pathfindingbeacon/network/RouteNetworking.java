package cn.quit5700.pathfindingbeacon.network;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.route.RouteEdge;
import cn.quit5700.pathfindingbeacon.route.RouteNode;
import cn.quit5700.pathfindingbeacon.route.RoutePersistentState;
import cn.quit5700.pathfindingbeacon.route.WorldRouteManager;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class RouteNetworking {
    public static final class_2960 ROUTE_SNAPSHOT = PathfindingBeaconMod.id("route_snapshot");

    private RouteNetworking() {
    }

    public static void registerServer() {
    }

    public static void syncWorld(class_3218 world) {
        for (class_3222 player : PlayerLookup.world(world)) {
            syncPlayer(player);
        }
    }

    public static void syncPlayer(class_3222 player) {
        RoutePersistentState state = WorldRouteManager.state(player.method_51469());
        class_2540 buf = PacketByteBufs.create();
        buf.method_10804(state.data().nodes().size());
        for (RouteNode node : state.data().nodes()) {
            buf.method_10804(node.number());
            buf.method_10807(WorldRouteManager.toBlockPos(node.position()));
            buf.method_52964(node.active());
        }
        buf.method_10804(state.data().allEdges().size());
        for (RouteEdge edge : state.data().allEdges()) {
            buf.method_10804(edge.number());
            buf.method_10807(WorldRouteManager.toBlockPos(edge.first()));
            buf.method_10807(WorldRouteManager.toBlockPos(edge.second()));
            buf.method_52974(edge.createdOrder());
        }
        ServerPlayNetworking.send(player, ROUTE_SNAPSHOT, buf);
    }
}
