package cn.quit5700.pathfindingbeacon.client;

import cn.quit5700.pathfindingbeacon.network.RouteNetworking;
import cn.quit5700.pathfindingbeacon.route.BeamColumnResolver;
import cn.quit5700.pathfindingbeacon.route.RouteEdge;
import cn.quit5700.pathfindingbeacon.route.RouteNode;
import cn.quit5700.pathfindingbeacon.route.RoutePosition;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ClientRouteState {
    private static final UUID SERVER_OWNER = new UUID(0L, 0L);
    private static volatile BeamColumnResolver resolver = BeamColumnResolver.resolve(List.of(), List.of());

    private ClientRouteState() {
    }

    public static BeamColumnResolver resolver() {
        return resolver;
    }

    public static void registerReceiver() {
        ClientPlayNetworking.registerGlobalReceiver(RouteNetworking.ROUTE_SNAPSHOT,
                (client, handler, buf, responseSender) -> {
                    int nodeCount = buf.method_10816();
                    List<RouteNode> nodes = new ArrayList<>(nodeCount);
                    for (int i = 0; i < nodeCount; i++) {
                        int number = buf.method_10816();
                        class_2338 pos = buf.method_10811();
                        boolean active = buf.readBoolean();
                        nodes.add(new RouteNode(number, SERVER_OWNER, toRoutePosition(pos), active));
                    }
                    int edgeCount = buf.method_10816();
                    List<RouteEdge> edges = new ArrayList<>(edgeCount);
                    for (int i = 0; i < edgeCount; i++) {
                        int number = buf.method_10816();
                        RoutePosition first = toRoutePosition(buf.method_10811());
                        RoutePosition second = toRoutePosition(buf.method_10811());
                        long createdOrder = buf.readLong();
                        edges.add(new RouteEdge(number, first, second, createdOrder));
                    }
                    client.execute(() -> resolver = BeamColumnResolver.resolve(nodes, edges));
                });
    }

    private static RoutePosition toRoutePosition(class_2338 pos) {
        return new RoutePosition(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }
}
