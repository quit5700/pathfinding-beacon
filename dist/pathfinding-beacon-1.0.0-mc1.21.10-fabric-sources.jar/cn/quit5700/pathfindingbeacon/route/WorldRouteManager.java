package cn.quit5700.pathfindingbeacon.route;

import cn.quit5700.pathfindingbeacon.network.RouteNetworking;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public final class WorldRouteManager {
    private WorldRouteManager() {
    }

    public static RoutePersistentState state(class_3218 world) {
        return world.method_17983().method_17924(RoutePersistentState.TYPE);
    }

    public static PlacementResult place(class_3218 world, int number, UUID player, class_2338 pos) {
        RoutePersistentState state = state(world);
        PlacementResult result = state.service().place(number, player, toRoutePosition(pos));
        state.method_80();
        RouteNetworking.syncWorld(world);
        return result;
    }

    public static boolean hasNumberAtColumn(class_3218 world, int number, int x, int z) {
        return state(world).data().nodes().stream().anyMatch(node ->
                node.number() == number && node.position().x() == x && node.position().z() == z);
    }

    public static boolean isActive(class_3218 world, RoutePosition position) {
        RouteNode node = state(world).data().node(position);
        return node != null && node.active();
    }

    public static boolean canRemove(class_3218 world, UUID player, class_2338 pos, boolean creative) {
        return state(world).service().canRemove(toRoutePosition(pos), player, creative);
    }

    public static void remove(class_3218 world, class_2338 pos) {
        RoutePersistentState state = state(world);
        if (state.service().remove(toRoutePosition(pos)) != null) {
            state.method_80();
            RouteNetworking.syncWorld(world);
        }
    }

    public static ReorderStatus reorder(
            class_3218 world,
            int number,
            UUID player,
            RoutePosition first,
            RoutePosition second,
            boolean creative
    ) {
        RoutePersistentState state = state(world);
        ReorderStatus result = state.service().reorder(number, player, first, second, creative);
        if (result == ReorderStatus.RECONNECTED || result == ReorderStatus.REORDERED) {
            state.method_80();
            RouteNetworking.syncWorld(world);
        }
        return result;
    }

    public static int clearColor(class_3218 world, int number) {
        RoutePersistentState state = state(world);
        List<RouteNode> removed = state.service().clearColor(number);
        state.method_80();
        for (RouteNode node : removed) {
            class_2338 pos = toBlockPos(node.position());
            world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);
        }
        RouteNetworking.syncWorld(world);
        return removed.size();
    }

    public static RoutePosition toRoutePosition(class_2338 pos) {
        return new RoutePosition(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static class_2338 toBlockPos(RoutePosition pos) {
        return new class_2338(pos.x(), pos.y(), pos.z());
    }
}
