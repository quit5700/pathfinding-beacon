package cn.quit5700.pathfindingbeacon.registry;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.block.PathfindingBlock;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModBlocks {
    public static final List<PathfindingBlock> ROUTE_BLOCKS = registerBlocks();

    private ModBlocks() {
    }

    private static List<PathfindingBlock> registerBlocks() {
        List<PathfindingBlock> result = new ArrayList<>(30);
        for (int number = 1; number <= 30; number++) {
            PathfindingBlock block = new PathfindingBlock(number);
            class_2378.method_10230(
                    class_7923.field_41175,
                    PathfindingBeaconMod.id("route_block_" + number),
                    block
            );
            result.add(block);
        }
        return List.copyOf(result);
    }

    public static int numberOf(class_2248 block) {
        return block instanceof PathfindingBlock pathfindingBlock ? pathfindingBlock.number() : 0;
    }

    public static void initialize() {
    }
}
