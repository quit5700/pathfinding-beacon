package cn.quit5700.pathfindingbeacon.registry;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class ModItemGroup {
    public static final class_1761 PATHFINDING = class_2378.method_10230(
            class_7923.field_44687,
            PathfindingBeaconMod.id("pathfinding"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.pathfinding_beacon.pathfinding"))
                    .method_47320(() -> new class_1799(ModItems.ROUTE_BLOCK_ITEMS.get(0)))
                    .method_47317((context, entries) -> {
                        ModItems.ROUTE_BLOCK_ITEMS.forEach(entries::method_45421);
                        entries.method_45421(ModItems.CANCELLER);
                        entries.method_45421(ModItems.SEQUENCE_REORDERER);
                    })
                    .method_47324()
    );

    private ModItemGroup() {
    }

    public static void initialize() {
    }
}
