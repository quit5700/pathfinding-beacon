package cn.quit5700.pathfindingbeacon.item;

import cn.quit5700.pathfindingbeacon.block.PathfindingBlock;
import cn.quit5700.pathfindingbeacon.route.ReorderStatus;
import cn.quit5700.pathfindingbeacon.route.RoutePosition;
import cn.quit5700.pathfindingbeacon.route.WorldRouteManager;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public final class SequenceReordererItem extends class_1792 {
    private static final Map<UUID, Selection> SELECTIONS = new HashMap<>();

    public SequenceReordererItem(class_1793 settings) {
        super(settings);
    }

    public boolean canMine(class_2680 state, class_1937 world, class_2338 pos, class_1657 miner) {
        return false;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if (!(context.method_8045() instanceof class_3218 world) || context.method_8036() == null) {
            return class_1269.field_5812;
        }
        if (!(world.method_8320(context.method_8037()).method_26204() instanceof PathfindingBlock block)) {
            return class_1269.field_5811;
        }

        UUID playerId = context.method_8036().method_5667();
        RoutePosition position = WorldRouteManager.toRoutePosition(context.method_8037());
        if (!WorldRouteManager.isActive(world, position)) {
            context.method_8036().method_7353(class_2561.method_43470("该方块未参与线路，无法重排").method_27694(style -> style.method_36139(0xFF5555)), true);
            return class_1269.field_5814;
        }

        Selection first = SELECTIONS.get(playerId);
        if (first == null || !first.worldKey().equals(world.method_27983().method_29177()) || first.number() != block.number()) {
            SELECTIONS.put(playerId, new Selection(world.method_27983().method_29177(), block.number(), position));
            context.method_8036().method_7353(class_2561.method_43470("已选择第一个" + block.number() + "号寻路方块"), true);
            return class_1269.field_5812;
        }

        SELECTIONS.remove(playerId);
        ReorderStatus status = WorldRouteManager.reorder(
                world,
                block.number(),
                playerId,
                first.position(),
                position,
                context.method_8036().method_68878()
        );
        class_2561 message = switch (status) {
            case RECONNECTED -> class_2561.method_43470("两段线路已连接");
            case REORDERED -> class_2561.method_43470("线路顺序已重排");
            case DENIED -> class_2561.method_43470("其他玩家已使用这个颜色，该操作没有作用").method_27694(style -> style.method_36139(0xFF5555));
            case INVALID -> class_2561.method_43470("请选择两个不同的同号有效方块").method_27694(style -> style.method_36139(0xFF5555));
        };
        context.method_8036().method_7353(message, true);
        return status == ReorderStatus.DENIED || status == ReorderStatus.INVALID
                ? class_1269.field_5814
                : class_1269.field_5812;
    }

    private record Selection(net.minecraft.class_2960 worldKey, int number, RoutePosition position) {
    }
}
