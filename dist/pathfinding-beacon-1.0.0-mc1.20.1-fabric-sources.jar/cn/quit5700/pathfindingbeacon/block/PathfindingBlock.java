package cn.quit5700.pathfindingbeacon.block;

import cn.quit5700.pathfindingbeacon.registry.ModItems;
import cn.quit5700.pathfindingbeacon.route.PlacementStatus;
import cn.quit5700.pathfindingbeacon.route.WorldRouteManager;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import org.jetbrains.annotations.Nullable;

public final class PathfindingBlock extends class_2248 {
    private final int number;

    public PathfindingBlock(int number) {
        super(class_4970.class_2251.method_9630(class_2246.field_10446)
                .method_9631(state -> 15)
                .method_9629(-1.0F, 3_600_000.0F)
                .method_50012(class_3619.field_15972));
        this.number = number;
    }

    public int number() {
        return number;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        if (context.method_8045() instanceof class_3218 world
                && WorldRouteManager.hasNumberAtColumn(world, number, context.method_8037().method_10263(), context.method_8037().method_10260())) {
            if (context.method_8036() != null) {
                context.method_8036().method_7353(class_2561.method_43470("已有同号码方块，不得放置").method_27694(style -> style.method_36139(0xFF5555)), true);
            }
            return null;
        }
        return method_9564();
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (world instanceof class_3218 serverWorld && placer instanceof class_1657 player) {
            PlacementStatus status = WorldRouteManager.place(serverWorld, number, player.method_5667(), pos).status();
            if (status == PlacementStatus.INACTIVE) {
                player.method_7353(class_2561.method_43470("其他玩家已使用这个颜色，该放置没有作用，请破坏")
                        .method_27694(style -> style.method_36139(0xFF5555)), true);
            }
        }
    }

    @Override
    public float method_9594(class_2680 state, class_1657 player, class_1922 world, class_2338 pos) {
        if (player.method_7337()) {
            return 1.0F;
        }
        if (player.method_6047().method_31574(ModItems.CANCELLER)) {
            if (!(world instanceof class_3218 serverWorld)) {
                return 0.34F;
            }
            return WorldRouteManager.canRemove(serverWorld, player.method_5667(), pos, false) ? 0.34F : 0.0F;
        }
        return 0.0F;
    }

    @Override
    public void method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.field_9236 && player.method_7337()) {
            method_9577(world, pos, new class_1799(this));
        }
        super.method_9576(world, pos, state, player);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204()) && world instanceof class_3218 serverWorld) {
            WorldRouteManager.remove(serverWorld, pos);
        }
        super.method_9536(state, world, pos, newState, moved);
    }
}
