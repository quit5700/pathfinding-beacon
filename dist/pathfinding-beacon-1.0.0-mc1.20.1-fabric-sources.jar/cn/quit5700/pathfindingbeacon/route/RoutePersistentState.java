package cn.quit5700.pathfindingbeacon.route;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public final class RoutePersistentState extends class_18 {
    public static final String ID = "pathfinding_beacon_routes";

    private final RouteData data;
    private final RouteService service;

    public RoutePersistentState() {
        this(new RouteData());
    }

    private RoutePersistentState(RouteData data) {
        this.data = data;
        this.service = new RouteService(data);
    }

    public RouteData data() {
        return data;
    }

    public RouteService service() {
        return service;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        RouteSnapshot snapshot = data.snapshot();
        class_2499 owners = new class_2499();
        snapshot.owners().forEach((number, owner) -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", number);
            entry.method_25927("Owner", owner);
            owners.add(entry);
        });
        nbt.method_10566("Owners", owners);

        class_2499 nodes = new class_2499();
        snapshot.nodes().forEach(node -> {
            class_2487 entry = writePosition(node.position());
            entry.method_10569("Number", node.number());
            entry.method_25927("PlacedBy", node.placedBy());
            entry.method_10556("Active", node.active());
            nodes.add(entry);
        });
        nbt.method_10566("Nodes", nodes);

        class_2499 orders = new class_2499();
        snapshot.orders().forEach((number, positions) -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", number);
            class_2499 values = new class_2499();
            positions.forEach(position -> values.add(writePosition(position)));
            entry.method_10566("Positions", values);
            orders.add(entry);
        });
        nbt.method_10566("Orders", orders);

        class_2499 edges = new class_2499();
        snapshot.edges().forEach(edge -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", edge.number());
            entry.method_10566("First", writePosition(edge.first()));
            entry.method_10566("Second", writePosition(edge.second()));
            entry.method_10544("CreatedOrder", edge.createdOrder());
            edges.add(entry);
        });
        nbt.method_10566("Edges", edges);
        nbt.method_10544("NextEdgeOrder", snapshot.nextEdgeOrder());
        return nbt;
    }

    public static RoutePersistentState fromNbt(class_2487 nbt) {
        Map<Integer, UUID> owners = new HashMap<>();
        class_2499 ownerList = nbt.method_10554("Owners", class_2520.field_33260);
        for (int i = 0; i < ownerList.size(); i++) {
            class_2487 entry = ownerList.method_10602(i);
            owners.put(entry.method_10550("Number"), entry.method_25926("Owner"));
        }

        List<RouteNode> nodes = new ArrayList<>();
        class_2499 nodeList = nbt.method_10554("Nodes", class_2520.field_33260);
        for (int i = 0; i < nodeList.size(); i++) {
            class_2487 entry = nodeList.method_10602(i);
            nodes.add(new RouteNode(
                    entry.method_10550("Number"),
                    entry.method_25926("PlacedBy"),
                    readPosition(entry),
                    entry.method_10577("Active")
            ));
        }

        Map<Integer, List<RoutePosition>> orders = new HashMap<>();
        class_2499 orderList = nbt.method_10554("Orders", class_2520.field_33260);
        for (int i = 0; i < orderList.size(); i++) {
            class_2487 entry = orderList.method_10602(i);
            class_2499 values = entry.method_10554("Positions", class_2520.field_33260);
            List<RoutePosition> positions = new ArrayList<>();
            for (int j = 0; j < values.size(); j++) {
                positions.add(readPosition(values.method_10602(j)));
            }
            orders.put(entry.method_10550("Number"), positions);
        }

        List<RouteEdge> edges = new ArrayList<>();
        class_2499 edgeList = nbt.method_10554("Edges", class_2520.field_33260);
        for (int i = 0; i < edgeList.size(); i++) {
            class_2487 entry = edgeList.method_10602(i);
            edges.add(new RouteEdge(
                    entry.method_10550("Number"),
                    readPosition(entry.method_10562("First")),
                    readPosition(entry.method_10562("Second")),
                    entry.method_10537("CreatedOrder")
            ));
        }

        RouteSnapshot snapshot = new RouteSnapshot(
                owners,
                nodes,
                orders,
                edges,
                Math.max(1L, nbt.method_10537("NextEdgeOrder"))
        );
        return new RoutePersistentState(RouteData.fromSnapshot(snapshot));
    }

    private static class_2487 writePosition(RoutePosition position) {
        class_2487 nbt = new class_2487();
        nbt.method_10569("X", position.x());
        nbt.method_10569("Y", position.y());
        nbt.method_10569("Z", position.z());
        return nbt;
    }

    private static RoutePosition readPosition(class_2487 nbt) {
        return new RoutePosition(nbt.method_10550("X"), nbt.method_10550("Y"), nbt.method_10550("Z"));
    }
}
