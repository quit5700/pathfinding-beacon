package cn.quit5700.pathfindingbeacon.event;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.network.RouteNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3489;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

public final class PlayerEvents {
    private static int ticks;

    private PlayerEvents() {
    }

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            handler.field_14140.method_7353(class_2561.method_43470("寻路器取消指令 idcancel <1-30>"), false);
            RouteNetworking.syncPlayer(handler.field_14140);
        });
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) ->
                RouteNetworking.syncPlayer(player));
        ServerTickEvents.END_SERVER_TICK.register(PlayerEvents::unlockRecipesForPickaxeOwners);
    }

    private static void unlockRecipesForPickaxeOwners(MinecraftServer server) {
        if (++ticks % 20 != 0) {
            return;
        }
        List<class_2960> ids = new ArrayList<>();
        ids.add(PathfindingBeaconMod.id("route_block_1"));
        for (int i = 2; i <= 30; i++) {
            ids.add(PathfindingBeaconMod.id("route_block_" + i));
        }
        ids.add(PathfindingBeaconMod.id("pathfinding_block_canceller"));
        ids.add(PathfindingBeaconMod.id("id_sequence_reorderer"));

        for (class_3222 player : server.method_3760().method_14571()) {
            boolean hasPickaxe = player.method_31548().field_7547.stream().anyMatch(PlayerEvents::isPickaxe);
            if (hasPickaxe) {
                player.method_7335(ids.toArray(class_2960[]::new));
            }
        }
    }

    private static boolean isPickaxe(class_1799 stack) {
        return stack.method_31573(class_3489.field_42614);
    }
}
