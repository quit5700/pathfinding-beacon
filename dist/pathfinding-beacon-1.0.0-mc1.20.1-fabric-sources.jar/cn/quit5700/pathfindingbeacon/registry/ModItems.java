package cn.quit5700.pathfindingbeacon.registry;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.item.CancellerItem;
import cn.quit5700.pathfindingbeacon.item.SequenceReordererItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModItems {
    public static final List<class_1747> ROUTE_BLOCK_ITEMS = registerBlockItems();
    public static final class_1792 CANCELLER = class_2378.method_10230(
            class_7923.field_41178,
            PathfindingBeaconMod.id("pathfinding_block_canceller"),
            new CancellerItem(new class_1792.class_1793().method_7889(1))
    );
    public static final class_1792 SEQUENCE_REORDERER = class_2378.method_10230(
            class_7923.field_41178,
            PathfindingBeaconMod.id("id_sequence_reorderer"),
            new SequenceReordererItem(new class_1792.class_1793().method_7889(1))
    );

    private ModItems() {
    }

    private static List<class_1747> registerBlockItems() {
        List<class_1747> result = new ArrayList<>(30);
        for (int i = 0; i < ModBlocks.ROUTE_BLOCKS.size(); i++) {
            class_1747 item = new class_1747(ModBlocks.ROUTE_BLOCKS.get(i), new class_1792.class_1793());
            class_2378.method_10230(class_7923.field_41178, PathfindingBeaconMod.id("route_block_" + (i + 1)), item);
            result.add(item);
        }
        return List.copyOf(result);
    }

    public static void initialize() {
    }
}
