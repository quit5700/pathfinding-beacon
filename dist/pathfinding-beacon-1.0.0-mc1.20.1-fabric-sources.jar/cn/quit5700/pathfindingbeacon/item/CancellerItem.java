package cn.quit5700.pathfindingbeacon.item;

import cn.quit5700.pathfindingbeacon.block.PathfindingBlock;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class CancellerItem extends class_1792 {
    public CancellerItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public boolean method_7885(class_2680 state, class_1937 world, class_2338 pos, class_1657 miner) {
        return state.method_26204() instanceof PathfindingBlock;
    }
}
