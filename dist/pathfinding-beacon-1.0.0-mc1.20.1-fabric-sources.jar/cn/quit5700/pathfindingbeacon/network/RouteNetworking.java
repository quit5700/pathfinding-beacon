package cn.quit5700.pathfindingbeacon.network;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.route.RouteEdge;
import cn.quit5700.pathfindingbeacon.route.RouteNode;
import cn.quit5700.pathfindingbeacon.route.RoutePosition;
import cn.quit5700.pathfindingbeacon.route.RoutePersistentState;
import cn.quit5700.pathfindingbeacon.route.WorldRouteManager;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class RouteNetworking {
    public static final class_2960 ROUTE_SNAPSHOT = PathfindingBeaconMod.id("route_snapshot");
    private static final UUID SERVER_OWNER = new UUID(0L, 0L);

    private RouteNetworking() {
    }

    public static void registerServer() {
    }

    public static void syncWorld(class_3218 world) {
        for (class_3222 player : PlayerLookup.world(world)) {
            syncPlayer(player);
        }
    }

    public static void syncPlayer(class_3222 player) {
        RoutePersistentState state = WorldRouteManager.state(player.method_51469());
        RouteSnapshotPayload payload = new RouteSnapshotPayload(
                List.copyOf(state.data().nodes()),
                List.copyOf(state.data().allEdges())
        );
        class_2540 buf = PacketByteBufs.create();
        payload.write(buf);
        ServerPlayNetworking.send(player, ROUTE_SNAPSHOT, buf);
    }

    public record RouteSnapshotPayload(List<RouteNode> nodes, List<RouteEdge> edges) {
        public void write(class_2540 buf) {
            buf.method_10804(nodes.size());
            for (RouteNode node : nodes) {
                buf.method_10804(node.number());
                buf.method_10807(WorldRouteManager.toBlockPos(node.position()));
                buf.writeBoolean(node.active());
            }
            buf.method_10804(edges.size());
            for (RouteEdge edge : edges) {
                buf.method_10804(edge.number());
                buf.method_10807(WorldRouteManager.toBlockPos(edge.first()));
                buf.method_10807(WorldRouteManager.toBlockPos(edge.second()));
                buf.writeLong(edge.createdOrder());
            }
        }

        public static RouteSnapshotPayload read(class_2540 buf) {
            int nodeCount = buf.method_10816();
            List<RouteNode> nodes = new ArrayList<>(nodeCount);
            for (int i = 0; i < nodeCount; i++) {
                int number = buf.method_10816();
                class_2338 pos = buf.method_10811();
                boolean active = buf.readBoolean();
                nodes.add(new RouteNode(number, SERVER_OWNER, toRoutePosition(pos), active));
            }
            int edgeCount = buf.method_10816();
            List<RouteEdge> edges = new ArrayList<>(edgeCount);
            for (int i = 0; i < edgeCount; i++) {
                int number = buf.method_10816();
                RoutePosition first = toRoutePosition(buf.method_10811());
                RoutePosition second = toRoutePosition(buf.method_10811());
                long createdOrder = buf.readLong();
                edges.add(new RouteEdge(number, first, second, createdOrder));
            }
            return new RouteSnapshotPayload(nodes, edges);
        }

        private static RoutePosition toRoutePosition(class_2338 pos) {
            return new RoutePosition(pos.method_10263(), pos.method_10264(), pos.method_10260());
        }
    }
}
