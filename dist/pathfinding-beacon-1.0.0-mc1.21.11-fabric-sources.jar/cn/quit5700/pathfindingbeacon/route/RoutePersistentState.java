package cn.quit5700.pathfindingbeacon.route;

import com.mojang.serialization.Codec;
import com.mojang.serialization.Dynamic;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_4844;
import net.minecraft.class_7225;

public final class RoutePersistentState extends class_18 {
    public static final String ID = "pathfinding_beacon_routes";
    public static final Codec<RoutePersistentState> CODEC = Codec.PASSTHROUGH.xmap(
            RoutePersistentState::fromDynamic,
            RoutePersistentState::toDynamic
    );
    public static final class_10741<RoutePersistentState> TYPE = new class_10741<>(
            ID,
            RoutePersistentState::new,
            CODEC,
            null
    );

    private final RouteData data;
    private final RouteService service;

    public RoutePersistentState() {
        this(new RouteData());
    }

    private RoutePersistentState(RouteData data) {
        this.data = data;
        this.service = new RouteService(data);
    }

    public RouteData data() {
        return data;
    }

    public RouteService service() {
        return service;
    }

    private static RoutePersistentState fromDynamic(Dynamic<?> dynamic) {
        return fromNbt((class_2487) dynamic.convert(class_2509.field_11560).getValue(), null);
    }

    private Dynamic<?> toDynamic() {
        return new Dynamic<>(class_2509.field_11560, writeNbt(new class_2487(), null));
    }

    public class_2487 writeNbt(class_2487 nbt, class_7225.class_7874 registryLookup) {
        RouteSnapshot snapshot = data.snapshot();
        class_2499 owners = new class_2499();
        snapshot.owners().forEach((number, owner) -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", number);
            entry.method_10539("Owner", class_4844.method_26275(owner));
            owners.add(entry);
        });
        nbt.method_10566("Owners", owners);

        class_2499 nodes = new class_2499();
        snapshot.nodes().forEach(node -> {
            class_2487 entry = writePosition(node.position());
            entry.method_10569("Number", node.number());
            entry.method_10539("PlacedBy", class_4844.method_26275(node.placedBy()));
            entry.method_10556("Active", node.active());
            nodes.add(entry);
        });
        nbt.method_10566("Nodes", nodes);

        class_2499 orders = new class_2499();
        snapshot.orders().forEach((number, positions) -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", number);
            class_2499 values = new class_2499();
            positions.forEach(position -> values.add(writePosition(position)));
            entry.method_10566("Positions", values);
            orders.add(entry);
        });
        nbt.method_10566("Orders", orders);

        class_2499 edges = new class_2499();
        snapshot.edges().forEach(edge -> {
            class_2487 entry = new class_2487();
            entry.method_10569("Number", edge.number());
            entry.method_10566("First", writePosition(edge.first()));
            entry.method_10566("Second", writePosition(edge.second()));
            entry.method_10544("CreatedOrder", edge.createdOrder());
            edges.add(entry);
        });
        nbt.method_10566("Edges", edges);
        nbt.method_10544("NextEdgeOrder", snapshot.nextEdgeOrder());
        return nbt;
    }

    public static RoutePersistentState fromNbt(class_2487 nbt, class_7225.class_7874 registryLookup) {
        Map<Integer, UUID> owners = new HashMap<>();
        class_2499 ownerList = nbt.method_68569("Owners");
        for (int i = 0; i < ownerList.size(); i++) {
            class_2487 entry = ownerList.method_68582(i);
            owners.put(entry.method_68083("Number", 0), readUuid(entry, "Owner"));
        }

        List<RouteNode> nodes = new ArrayList<>();
        class_2499 nodeList = nbt.method_68569("Nodes");
        for (int i = 0; i < nodeList.size(); i++) {
            class_2487 entry = nodeList.method_68582(i);
            nodes.add(new RouteNode(
                    entry.method_68083("Number", 0),
                    readUuid(entry, "PlacedBy"),
                    readPosition(entry),
                    entry.method_68566("Active", false)
            ));
        }

        Map<Integer, List<RoutePosition>> orders = new HashMap<>();
        class_2499 orderList = nbt.method_68569("Orders");
        for (int i = 0; i < orderList.size(); i++) {
            class_2487 entry = orderList.method_68582(i);
            class_2499 values = entry.method_68569("Positions");
            List<RoutePosition> positions = new ArrayList<>();
            for (int j = 0; j < values.size(); j++) {
                positions.add(readPosition(values.method_68582(j)));
            }
            orders.put(entry.method_68083("Number", 0), positions);
        }

        List<RouteEdge> edges = new ArrayList<>();
        class_2499 edgeList = nbt.method_68569("Edges");
        for (int i = 0; i < edgeList.size(); i++) {
            class_2487 entry = edgeList.method_68582(i);
            edges.add(new RouteEdge(
                    entry.method_68083("Number", 0),
                    readPosition(entry.method_68568("First")),
                    readPosition(entry.method_68568("Second")),
                    entry.method_68080("CreatedOrder", 0L)
            ));
        }

        RouteSnapshot snapshot = new RouteSnapshot(
                owners,
                nodes,
                orders,
                edges,
                Math.max(1L, nbt.method_68080("NextEdgeOrder", 1L))
        );
        return new RoutePersistentState(RouteData.fromSnapshot(snapshot));
    }

    private static class_2487 writePosition(RoutePosition position) {
        class_2487 nbt = new class_2487();
        nbt.method_10569("X", position.x());
        nbt.method_10569("Y", position.y());
        nbt.method_10569("Z", position.z());
        return nbt;
    }

    private static RoutePosition readPosition(class_2487 nbt) {
        return new RoutePosition(nbt.method_68083("X", 0), nbt.method_68083("Y", 0), nbt.method_68083("Z", 0));
    }

    private static UUID readUuid(class_2487 nbt, String key) {
        return nbt.method_10561(key)
                .map(class_4844::method_26276)
                .orElse(new UUID(0L, 0L));
    }
}
