package cn.quit5700.pathfindingbeacon.command;

import cn.quit5700.pathfindingbeacon.route.WorldRouteManager;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class IdCancelCommand {
    private static final String COMMAND = "idcancel";

    private IdCancelCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(method_9247(COMMAND)
                        .requires(source -> source.method_9228() instanceof class_3222)
                        .then(method_9244("number", IntegerArgumentType.integer(1, 30))
                                .executes(context -> {
                                    class_3222 player = context.getSource().method_9207();
                                    int number = IntegerArgumentType.getInteger(context, "number");
                                    int removed = WorldRouteManager.clearColor(player.method_51469(), number);
                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470("已删除本维度" + number + "号寻路方块：" + removed + "个"),
                                            false
                                    );
                                    return removed;
                                }))));
    }
}
