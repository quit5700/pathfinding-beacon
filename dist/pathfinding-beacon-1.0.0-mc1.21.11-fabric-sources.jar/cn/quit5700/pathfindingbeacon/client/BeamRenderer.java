package cn.quit5700.pathfindingbeacon.client;

import cn.quit5700.pathfindingbeacon.RouteColors;
import cn.quit5700.pathfindingbeacon.route.BeamColumnResolver;
import cn.quit5700.pathfindingbeacon.route.Column;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public final class BeamRenderer {
    private static final float HALF_WIDTH = 0.16F;
    private static final int ALPHA = 190;

    private BeamRenderer() {
    }

    public static void register() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(BeamRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || context.matrices() == null) {
            return;
        }
        BeamColumnResolver resolver = ClientRouteState.resolver();
        if (resolver.columns().isEmpty()) {
            return;
        }

        class_243 camera = client.field_1773.method_19418().method_71156();
        int renderDistance = client.field_1690.method_42503().method_41753() * 16 + 16;
        double maxDistanceSquared = (double) renderDistance * renderDistance;
        long second = System.currentTimeMillis() / 1000L;
        float bottom = client.field_1687.method_8597().comp_651();
        float top = bottom + client.field_1687.method_8597().comp_652();

        class_4587 matrices = context.matrices();
        matrices.method_22903();
        matrices.method_22904(-camera.field_1352, -camera.field_1351, -camera.field_1350);
        Matrix4f matrix = matrices.method_23760().method_23761();

        class_4588 buffer = context.consumers().method_73477(class_12249.method_76023());
        for (Column column : resolver.columns()) {
            double dx = column.x() + 0.5D - camera.field_1352;
            double dz = column.z() + 0.5D - camera.field_1350;
            if (dx * dx + dz * dz > maxDistanceSquared) {
                continue;
            }
            int number = resolver.colorAt(column, second);
            if (number == 0) {
                continue;
            }
            int rgb = RouteColors.rgb(number);
            int red = rgb >> 16 & 0xFF;
            int green = rgb >> 8 & 0xFF;
            int blue = rgb & 0xFF;
            addBeam(buffer, matrix, column.x() + 0.5F, bottom, top, column.z() + 0.5F, red, green, blue);
        }
        matrices.method_22909();
    }

    private static void addBeam(
            class_4588 buffer,
            Matrix4f matrix,
            float x,
            float bottom,
            float top,
            float z,
            int red,
            int green,
            int blue
    ) {
        float minX = x - HALF_WIDTH;
        float maxX = x + HALF_WIDTH;
        float minZ = z - HALF_WIDTH;
        float maxZ = z + HALF_WIDTH;

        quad(buffer, matrix, minX, bottom, minZ, minX, top, minZ, maxX, top, minZ, maxX, bottom, minZ, red, green, blue);
        quad(buffer, matrix, maxX, bottom, maxZ, maxX, top, maxZ, minX, top, maxZ, minX, bottom, maxZ, red, green, blue);
        quad(buffer, matrix, minX, bottom, maxZ, minX, top, maxZ, minX, top, minZ, minX, bottom, minZ, red, green, blue);
        quad(buffer, matrix, maxX, bottom, minZ, maxX, top, minZ, maxX, top, maxZ, maxX, bottom, maxZ, red, green, blue);
    }

    private static void quad(
            class_4588 buffer,
            Matrix4f matrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            float x3, float y3, float z3,
            float x4, float y4, float z4,
            int red, int green, int blue
    ) {
        buffer.method_22918(matrix, x1, y1, z1).method_1336(red, green, blue, ALPHA);
        buffer.method_22918(matrix, x2, y2, z2).method_1336(red, green, blue, ALPHA);
        buffer.method_22918(matrix, x3, y3, z3).method_1336(red, green, blue, ALPHA);
        buffer.method_22918(matrix, x4, y4, z4).method_1336(red, green, blue, ALPHA);
    }
}
