package cn.quit5700.pathfindingbeacon.registry;

import cn.quit5700.pathfindingbeacon.PathfindingBeaconMod;
import cn.quit5700.pathfindingbeacon.item.CancellerItem;
import cn.quit5700.pathfindingbeacon.item.SequenceReordererItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItems {
    public static final List<class_1747> ROUTE_BLOCK_ITEMS = registerBlockItems();
    private static final class_2960 CANCELLER_ID = PathfindingBeaconMod.id("pathfinding_block_canceller");
    private static final class_2960 SEQUENCE_REORDERER_ID = PathfindingBeaconMod.id("id_sequence_reorderer");
    public static final class_1792 CANCELLER = class_2378.method_10230(
            class_7923.field_41178,
            CANCELLER_ID,
            new CancellerItem(itemSettings(CANCELLER_ID).method_7889(1))
    );
    public static final class_1792 SEQUENCE_REORDERER = class_2378.method_10230(
            class_7923.field_41178,
            SEQUENCE_REORDERER_ID,
            new SequenceReordererItem(itemSettings(SEQUENCE_REORDERER_ID).method_7889(1))
    );

    private ModItems() {
    }

    private static List<class_1747> registerBlockItems() {
        List<class_1747> result = new ArrayList<>(30);
        for (int i = 0; i < ModBlocks.ROUTE_BLOCKS.size(); i++) {
            class_2960 id = PathfindingBeaconMod.id("route_block_" + (i + 1));
            class_1747 item = new class_1747(ModBlocks.ROUTE_BLOCKS.get(i), itemSettings(id));
            class_2378.method_10230(class_7923.field_41178, id, item);
            result.add(item);
        }
        return List.copyOf(result);
    }

    private static class_1792.class_1793 itemSettings(class_2960 id) {
        return new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, id));
    }

    public static void initialize() {
    }
}
